﻿#include<iostream>
#include<string>
#include<windows.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>


/*
(AR)

مرحبا بكم في تسجيل الدخول البسيط
c++ تم برمجة هذا المشروع البسيط بهدف التعلم للمبتادين بلغة .
SKLتم تطوير المشروع من قبل 
المشروع مفتوح المصدر تستطيع التغير فيه كما تريد.
يرجى زيارة موقعنا على جيت هوب للمزيد من المشاريع مفتوحة المصدر : https://github.com/salehSKl1

*/

/*
(EN)

Welcome to simple login.
This simple project has been programmed with the aim of learning for beginners in C++.
The project was developed by SKL
The project is open source and you can change it as you like.
Please visit our GitHub website for more open source projects: https://github.com/salehSKl1
*/



/*
The Colors

1. BLACK         0
2. BLUE          1
3. GREEN         2
4. CYAN          3
5. RED           4
6. MAGENTA       5
7. BROWN         6
8. LIGHTGRAY     7
9. DARKGRAY      8
10. LIGHTBLUE    9
11. LIGHTGREEN   10
12. LIGHTCYAN    11
13. LIGHTRED     12
14. YELLOW       14
15. WHITE        15
16. LIGHTMAGENTA 13
*/

using namespace std;



int main()
{
  
   system("cls");
   string username = "";
   string password = "";
   string ReUsername = "";
   string RePassword = "";
   int Login;
   string Regester = "";
   bool loginSuccess = false;
   bool RegesterSuccess = false;

    HANDLE h = GetStdHandle ( STD_OUTPUT_HANDLE);
    

    SetConsoleTextAttribute(h,4);
    
    cout << "\t\t\t -----(Hello Guset Welcome To main Page Login / Regester )-----\n";
    cout <<"\t\t\t-------[ Warning Do not type anything other than 1 or 2 ]-------\n\n\n";
    cout <<">>>>-Type 1 To Login Or 2 To Regester :  ";
    SetConsoleTextAttribute(h,1);
    cin >> Login;
    
    
    switch (Login)
    {
        case 1:
           system("cls");
           SetConsoleTextAttribute(h,4);
           cout << "\t  |=====V Hello And Welcome To Login Page. Please Enter The Login informations Below V=====|\n";
        
         do
         {
          SetConsoleTextAttribute(h,5);           
          cout << "\n\n\n\n You Are In Login Page if You Want To Register Type (( try )) in username and pasword\n\n\n\n";     
          SetConsoleTextAttribute(h,14);       
          cout << " Username : ";
          SetConsoleTextAttribute(h,1);
          cin >> username;
          SetConsoleTextAttribute(h,14);
          cout << " Password : ";
          SetConsoleTextAttribute(h,1);
          cin >> password;


        
          if (password == "try"  && username == "try")
          {
            cout << "You Are In Going To Register ";
            system("pause");
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "\t  |=====V Hello And Welcome To Register Page. Please Enter The Register informations Below V=====|\n\n\n";
            SetConsoleTextAttribute(h,14);
            cout << "Enter Username : ";
            SetConsoleTextAttribute(h,1);
            cin >> ReUsername;
            SetConsoleTextAttribute(h,14);
            cout << "Enter password : ";
            SetConsoleTextAttribute(h,1);
            cin >> RePassword;

             if (ReUsername == ReUsername && RePassword == RePassword)
            {
                system("cls");
                SetConsoleTextAttribute(h,1);
                cout<< "\n\n\nRegester Successful\n\n";
                bool loginSuccess = true;
                system("pause");
            }
          

          }
          else if (username == ReUsername && password == RePassword)
          {
            system("cls");
            SetConsoleTextAttribute(h,1);
            cout<< "\n\n\nLogin Successful\n\n";
            bool loginSuccess = true;
            
            exit(1);
          }
            
          else
          {
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "Incorrect username or password\n";
            cout << "Please Try Again!.\n";
          }


         } while (!loginSuccess);

         case 2:
           do
        {
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "\t  |=====V Hello And Welcome To Register Page. Please Enter The Register informations Below V=====|\n\n\n";
            SetConsoleTextAttribute(h,14);
            cout << "Enter Username : ";
            SetConsoleTextAttribute(h,1);
            cin >> ReUsername;
            SetConsoleTextAttribute(h,14);
            cout << "Enter password : ";
            SetConsoleTextAttribute(h,1);
            cin >> RePassword;

             if (ReUsername == ReUsername && RePassword == RePassword)
          {
            system("cls");
            SetConsoleTextAttribute(h,1);
            cout<< "\n\n\nRegester Successful\n\n";
            bool loginSuccess = true;
            system("pause");
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "\t\t ((( Login )))\n\n ";
            SetConsoleTextAttribute(h,14);
            cout << "Username : ";
            SetConsoleTextAttribute(h,1);
            cin >> username;
            SetConsoleTextAttribute(h,14);
            cout << " Password : ";
            SetConsoleTextAttribute(h,1);
            cin >> password;


          if (username == ReUsername && password == RePassword)
          {
            system("cls");
            SetConsoleTextAttribute(h,1);
            cout<< "\n\n\nLogin Successful\n\n";
            bool loginSuccess = true;
            system("pause");          
            exit(1);
          }
            
          else
          {
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "Incorrect username or password\n";
            cout << "Please Try Again!.\n\n\n";
            system("pause");
          }
          }
           else
          {
            system("cls");
            SetConsoleTextAttribute(h,4);
            cout << "Incorrect username or password\n";
            cout << "Please Try Again!.\n";
          }

          

        } while (!loginSuccess);
        break;
    
    default:
        break;
    }

        do
        {
            SetConsoleTextAttribute(h,1);
            cout << "01001000 01100101 01101100 01101100 01101111 00100000 01010111 01101111 01110010 01101100 01100100  ";


        } while (!loginSuccess);
        
         return 0;
         
               
}